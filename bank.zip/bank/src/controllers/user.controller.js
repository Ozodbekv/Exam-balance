const User = require('../src/models/user.model');
const bcrypt = require('bcrypt');

exports.getAllUsers = async (req, res) => {
    if (!req.user.isAdmin) return res.status(403).json({ message: "Forbidden" });
    const users = await User.find();
    res.json(users);
};

exports.changePassword = async (req, res) => {
    if (!req.user.isAdmin) return res.status(403).json({ message: "Forbidden" });
    const { userId, newPassword } = req.body;
    const hashed = await bcrypt.hash(newPassword, 10);
    await User.findByIdAndUpdate(userId, { password: hashed });
    res.json({ message: "Password updated" });
};
