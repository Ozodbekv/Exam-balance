const Category = require('../models/category.model');

exports.createCategory = async (req, res) => {
    const category = await Category.create({ ...req.body, userId: req.user.id });
    res.status(201).json(category);
};

exports.getCategories = async (req, res) => {
    const categories = await Category.find({ userId: req.user.id });
    res.json(categories);
};

exports.updateCategory = async (req, res) => {
    const category = await Category.findOneAndUpdate({ _id: req.params.id, userId: req.user.id }, req.body, { new: true });
    res.json(category);
};

exports.deleteCategory = async (req, res) => {
    await Category.findOneAndDelete({ _id: req.params.id, userId: req.user.id });
    res.json({ message: "Deleted" });
};
