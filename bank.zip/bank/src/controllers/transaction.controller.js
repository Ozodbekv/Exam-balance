const Transaction = require('../models/transaction.model');
const User = require('../models/user.model');

exports.createTransaction = async (req, res) => {
    const { amount, categoryId, type } = req.body;
    const transaction = await Transaction.create({
        userId: req.user.id, categoryId, amount, type
    });

    const user = await User.findById(req.user.id);
    user.balance += (type === 'income' ? amount : -amount);
    await user.save();

    res.status(201).json(transaction);
};

exports.getHistory = async (req, res) => {
    const history = await Transaction.find({ userId: req.user.id }).populate('categoryId');
    res.json(history);
};

exports.updateTransaction = async (req, res) => {
    const oldTx = await Transaction.findOne({ _id: req.params.id, userId: req.user.id });
    const user = await User.findById(req.user.id);
    if (!oldTx) return res.status(404).json({ message: "Not found" });

    user.balance -= (oldTx.type === 'income' ? oldTx.amount : -oldTx.amount);
    const updatedTx = await Transaction.findByIdAndUpdate(req.params.id, req.body, { new: true });
    user.balance += (updatedTx.type === 'income' ? updatedTx.amount : -updatedTx.amount);
    await user.save();

    res.json(updatedTx);
};

exports.deleteTransaction = async (req, res) => {
    const tx = await Transaction.findOne({ _id: req.params.id, userId: req.user.id });
    if (!tx) return res.status(404).json({ message: "Not found" });

    const user = await User.findById(req.user.id);
    user.balance -= (tx.type === 'income' ? tx.amount : -tx.amount);
    await user.save();
    await tx.deleteOne();

    res.json({ message: "Transaction deleted" });
};
