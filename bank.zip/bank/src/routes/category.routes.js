const router = require('express').Router();
const controller = require('../controllers/category.controller');

router.post('/', controller.createCategory);
router.get('/', controller.getCategories);
router.put('/:id', controller.updateCategory);
router.delete('/:id', controller.deleteCategory);

module.exports = router;
