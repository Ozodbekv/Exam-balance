const router = require('express').Router();
const controller = require('../controllers/transaction.controller');

router.post('/', controller.createTransaction);
router.get('/history', controller.getHistory);
router.put('/:id', controller.updateTransaction);
router.delete('/:id', controller.deleteTransaction);

module.exports = router;
